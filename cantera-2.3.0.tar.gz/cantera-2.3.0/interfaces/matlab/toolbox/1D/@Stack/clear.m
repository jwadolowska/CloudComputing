function clear(s)
% CLEAR  Delete the C++ Sim1D object.
% clear(s)
% :param s:
%     Instance of class :mat:func:`Stack`
%

stack_methods(s.stack_id, 110);
