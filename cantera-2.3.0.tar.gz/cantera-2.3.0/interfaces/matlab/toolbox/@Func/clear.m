function clear(f)
% CLEAR  Delete the C++ Func1 object.
% clear(f)
% :param f:
%     Instance of class :mat:func:`Func`
%

funcmethods(f.index, 1);
