from cantera.mixmaster.main import MixMaster


def main():
    MixMaster()

if __name__ == '__main__':
    main()
