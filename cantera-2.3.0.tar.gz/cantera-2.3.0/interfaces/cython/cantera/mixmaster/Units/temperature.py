from . import SI

K = SI.kelvin
R = (9.0/5.0)*K
