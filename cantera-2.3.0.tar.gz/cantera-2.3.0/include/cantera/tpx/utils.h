//! @file utils.h
#ifndef TPX_UTILS_H
#define TPX_UTILS_H

#include "cantera/tpx/Sub.h"

namespace tpx
{
Substance* GetSub(int isub);
}

#endif
