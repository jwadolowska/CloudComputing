### Cantera version

### Operating System

### Python/MATLAB version

### Expected Behavior

### Actual Behavior

### Steps to reproduce
1.
2.
3.
