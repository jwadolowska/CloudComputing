The full Matlab xUnit package (including documentation) is available from:

http://www.mathworks.com/matlabcentral/fileexchange/22846-matlab-xunit-test-framework
